import React from 'react';
import './FooterDashboard.scss';
import Model from "../../../landing/media/carretera_ 1.png";


function FooterDashboard() {
    return (
        <div className='footer-model'>
            <img src={Model}></img>
        </div>
    );
}

export default FooterDashboard;