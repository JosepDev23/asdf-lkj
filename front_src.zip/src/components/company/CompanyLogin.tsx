import '../landing/components/TopPage.scss';
import Login from '../user/auth/login/Login';
import "./SalesPage.scss";



export default function CompanyLogin() {
    return (
        <div>
            <Login company/>
        </div>
    );
}
