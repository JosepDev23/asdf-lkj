export class CompanyEntity{
    name: string;
    email: string
}