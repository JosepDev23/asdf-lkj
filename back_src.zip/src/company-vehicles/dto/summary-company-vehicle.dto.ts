export class SummaryCompanyVehicleDto{
    type: string;
    make: string;
    model: string;
    year: number;
    total_emissions: number;
    consumption: number;
    capacity: number;
}