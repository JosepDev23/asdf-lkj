export class CompanyVehicle {}
