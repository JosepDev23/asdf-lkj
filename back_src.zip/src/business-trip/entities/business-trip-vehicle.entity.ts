export class BusinessTripVehicle {}
