export class TemplateCompanyRoute {
    from: string;  
    to: string;  
    distance: number;  
    capacity: number;  
    employee: string;  
    date: Date;
    frequency: number[];
}
  