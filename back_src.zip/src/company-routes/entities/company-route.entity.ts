export class CompanyRoute {}
