export class CreateFleetDto {
    name: string;
}
